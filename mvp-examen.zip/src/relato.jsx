import React from "react";

class Relato extends React.Component {
  render() {
    return <h2 className="historia">{this.props.relato}</h2>;
  }
}

export default Relato;
